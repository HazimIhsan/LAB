<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 4:29:02 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>

<h3>Calculate Your BMI</h3>

<form action="processBMI.jsp" method="POST">
    <label for="weight">Weight (kg):</label>
    <input type="number" id="weight" name="weight" step="0.01" min="0.1" placeholder="Enter weight in kg" required>

    <label for="height">Height (m):</label>
    <input type="number" id="height" name="height" step="0.01" min="0.1" placeholder="Enter height in meters" required>

    <button type="submit">Submit</button>
</form>

<%@ include file="footer.jsp" %>
