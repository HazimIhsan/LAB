<%-- 
    Document   : insuranceQuotation
    Created on : 21 Apr 2026, 4:19:55 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <div class="header-title">Insurance Quotation</div>
    
    <div class="card-container">
        <h2>Insurance Calculation</h2>
        
        <form action="processInsuranceQuo.jsp" method="POST">
            
            <div class="form-group">
                <label for="icno">IC No*</label>
                <input type="text" id="icno" name="icno" placeholder="E.g. 921210-08-3478" required>
            </div>
            
            <div class="form-group">
                <label for="name">Name*</label>
                <input type="text" id="name" name="name" placeholder="Enter name" required>
            </div>
            
            <div class="form-group">
                <label for="price">Market Price*</label>
                <input type="number" id="price" name="price" placeholder="Price" step="0.01" required>
            </div>
            
            <div class="form-group">
                <label for="coverage">Coverage Type</label>
                <select id="coverage" name="coverage" required>
                    <option value="comprehensive">Comprehensive</option>
                    <option value="thirdparty">Third Party</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="ncd">No Claims Discount (NCD)</label>
                <select id="ncd" name="ncd" required>
                    <option value="0">0%</option>
                    <option value="0.10">10%</option>
                    <option value="0.25">25%</option>
                    <option value="0.30">30%</option>
                    <option value="0.45">45%</option>
                    <option value="0.55">55%</option>
                </select>
            </div>
            
            <div class="button-group">
                <button type="submit">Submit</button>
                <button type="reset">Cancel</button>
            </div>
            
        </form>
    </div>

</body>
</html>
