<%-- 
    Document   : processCustomer
    Created on : 21 Apr 2026, 3:06:25 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Customer Discount Result</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        
    </head>
    <body>

        <%
            // Your exact Java Logic (Scriptlet)
            final double price = 10.0;
            String cust_no = request.getParameter("customerCode");
            String cust_type = request.getParameter("customerType");
            
            int quantity = 0;
            try {
                quantity = Integer.parseInt(request.getParameter("quantity"));
            } catch (Exception e) {
                quantity = 0;
            }
            
            double total = 0;
            String message = "";
            
            if (cust_type != null && cust_type.equals("1") && quantity > 100) {
                message = "You're entitled to 10% discount";
                total = quantity * price * 0.9;
            } else if (cust_type != null && cust_type.equals("2") && quantity > 100) {
                message = "You're entitled to 25% discount";
                total = quantity * price * 0.75;
            } else {
                message = "You're not entitled to any discount";
                total = quantity * price;
            }

            // Display customer type
            String custTypeDisplay = (cust_type != null && cust_type.equals("1")) 
                                     ? "Normal Customer" : "Privilege Customer";
        %>

        <div class="header-title">Customer Discount Result</div>
        
        <div class="card-container">
            <h2>Transaction Summary</h2>
            
            <div class="result-group">
                <div class="result-label">Customer Code:</div>
                <div class="result-value"><%= cust_no != null ? cust_no : "" %></div>
            </div>

            <div class="result-group">
                <div class="result-label">Quantity:</div>
                <div class="result-value"><%= quantity %></div>
            </div>

            <div class="result-group">
                <div class="result-label">Customer Type:</div>
                <div class="result-value"><%= custTypeDisplay %></div>
            </div>

            <div class="result-group">
                <div class="result-label">Status:</div>
                <div class="result-value"><%= message %></div>
            </div>

            <div class="result-group">
                <div class="result-label">Total Amount:</div>
                <div class="result-value">RM <%= String.format("%.2f", total) %></div>
            </div>

            <button onclick="window.history.back()">Back</button>

        </div>

    </body>
</html>