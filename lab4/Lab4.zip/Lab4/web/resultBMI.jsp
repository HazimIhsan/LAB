<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026, 4:30:11 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ include file="header.jsp" %>

<h3>Your BMI Result</h3>

<p><strong>Calculated BMI:</strong> <%= request.getParameter("bmiResult") %></p>
<p><strong>Health Category:</strong> <%= request.getParameter("bmiCategory") %></p>

<br>
<a href="bmiCalculator.jsp" style="display: inline-block; padding: 10px 20px; background-color: #0056b3; color: white; text-decoration: none; border-radius: 4px;">Recalculate</a>

<%@ include file="footer.jsp" %>
