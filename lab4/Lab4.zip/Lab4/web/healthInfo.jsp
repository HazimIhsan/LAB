<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 4:30:36 pm
    Author     : USER
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>

<%@ include file="header.jsp" %>

<h3>BMI Categories Guide</h3>

<%
    // 9. Store BMI categories using an ArrayList
    // We use a String array inside the ArrayList to hold both the range and the category name
    ArrayList<String[]> bmiList = new ArrayList<>();
    bmiList.add(new String[]{"BMI < 18.5", "Underweight"});
    bmiList.add(new String[]{"18.5 \u2264 BMI \u2264 25", "Normal"});
    bmiList.add(new String[]{"BMI > 25", "Overweight"});
%>

<table>
    <thead>
        <tr>
            <th>BMI Range</th>
            <th>Health Category</th>
        </tr>
    </thead>
    <tbody>
        <% 
            // Loop through the ArrayList
            for(String[] row : bmiList) { 
        %>
            <tr>
                <td><%= row[0] %></td>
                <td><%= row[1] %></td>
            </tr>
        <% 
            } 
        %>
    </tbody>
</table>

<%@ include file="footer.jsp" %>