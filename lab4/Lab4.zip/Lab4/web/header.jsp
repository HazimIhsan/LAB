<%-- 
    Document   : header
    Created on : 21 Apr 2026, 4:27:51 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Healthy Lifestyle Awareness Program</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f9; margin: 0; color: #333; }
        header { background-color: #0056b3; color: white; padding: 20px; text-align: center; }
        header h2 { margin: 0 0 15px 0; }
        nav a { color: white; text-decoration: none; font-weight: bold; margin: 0 15px; padding: 5px 10px; border-radius: 4px; }
        nav a:hover { background-color: #003d82; }
        .container { background: white; max-width: 600px; margin: 30px auto; padding: 25px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); border-radius: 8px; }
        input[type="number"] { width: 100%; padding: 10px; margin: 10px 0 20px 0; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { background-color: #28a745; color: white; padding: 10px 20px; border: none; cursor: pointer; border-radius: 4px; font-size: 1em; }
        button:hover { background-color: #218838; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <header>
        <h2>Healthy Lifestyle Awareness Program</h2>
        <nav>
            <a href="bmiCalculator.jsp">BMI Calculator</a>
            <a href="healthInfo.jsp">Health Information</a>
        </nav>
    </header>
    <div class="container">
