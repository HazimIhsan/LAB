<%-- 
    Document   : subjectInfo
    Created on : 21 Apr 2026, 4:01:36 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Subject Information</title>
    <style>
        /* Small styling to ensure paragraphs look clean inside the card */
        p {
            margin: 8px 0;
            font-size: 0.9em;
            color: #333;
        }
    </style>
</head>
<body>
    
    <p>Code: <%= request.getParameter("code") %></p>
    <p>Subject: <%= request.getParameter("subject") %></p>
    <p>Credit: <%= request.getParameter("credit") %></p>

</body>
</html>
