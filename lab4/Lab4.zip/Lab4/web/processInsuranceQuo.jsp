<%-- 
    Document   : processInsuranceQuo
    Created on : 21 Apr 2026, 4:23:17 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation Result</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <%
        // 1. Retrieve form data
        String icno = request.getParameter("icno");
        String name = request.getParameter("name");
        String coverage = request.getParameter("coverage");
        String ncdStr = request.getParameter("ncd");
        
        double price = 0;
        double ncd = 0;
        
        try {
            if (request.getParameter("price") != null) {
                price = Double.parseDouble(request.getParameter("price"));
            }
            if (ncdStr != null) {
                ncd = Double.parseDouble(ncdStr);
            }
        } catch (Exception e) {
            price = 0;
            ncd = 0;
        }
        
        // 2. Business Logic
        double rate = 0;
        String coverageDisplay = "";
        
        if ("comprehensive".equals(coverage)) {
            rate = 0.05; // 5%
            coverageDisplay = "Comprehensive";
        } else {
            rate = 0.03; // 3%
            coverageDisplay = "Third Party";
        }
        
        // 3. Base insurance calculation
        double insurance = price * rate;
        
        // 4. Apply NCD discount
        double discount = insurance * ncd;
        double afterNCD = insurance - discount;
        
        // 5. Add 8% SST
        double sst = afterNCD * 0.08;
        double finalAmount = afterNCD + sst;
    %>

    <div class="header-title">Insurance Quotation Result</div>
    
    <div class="card-container">
        
        <div class="result-group">
            <div class="result-label">IC No:</div>
            <div class="result-value"><%= icno != null ? icno : "" %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">Name:</div>
            <div class="result-value"><%= name != null ? name : "" %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">Market Price (RM):</div>
            <div class="result-value"><%= String.format("%.2f", price) %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">Coverage Type:</div>
            <div class="result-value"><%= coverageDisplay %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">NCD:</div>
            <div class="result-value"><%= String.format("%.0f", ncd * 100) %>%</div>
        </div>

        <hr style="border: 0; border-top: 1px solid #666; margin: 25px 0 15px 0;">

        <div class="result-group">
            <div class="result-label">Base Insurance:</div>
            <div class="result-value">RM <%= String.format("%.2f", insurance) %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">NCD Discount:</div>
            <div class="result-value">RM <%= String.format("%.2f", discount) %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">After NCD:</div>
            <div class="result-value">RM <%= String.format("%.2f", afterNCD) %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">SST (8%):</div>
            <div class="result-value">RM <%= String.format("%.2f", sst) %></div>
        </div>
        
        <div class="result-group">
            <div class="result-label">Final Insurance Amount:</div>
            <div class="result-value" style="font-weight: bold; font-size: 1.1em; color: #000;">
                RM <%= String.format("%.2f", finalAmount) %>
            </div>
        </div>

        <button onclick="window.history.back()">Back</button>
        
    </div>

</body>
</html>