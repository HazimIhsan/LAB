<%-- 
    Document   : processCurrency
    Created on : 21 Apr 2026, 3:06:25 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Application Result</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>

        <%!
            // Define constant exchange rates
            final double USD = 0.25;
            final double EURO = 0.21;
            final double JPY = 40;
            final double SGD = 0.32;

            // Method to calculate conversion
            private double calculateRate(String currency, int amount) {
                double currencyChange = 0.0;
                if (currency != null) {
                    if (currency.equals("1")) {
                        currencyChange = amount * USD;
                    } else if (currency.equals("2")) {
                        currencyChange = amount * EURO;
                    } else if (currency.equals("3")) {
                        currencyChange = amount * JPY;
                    } else {
                        currencyChange = amount * SGD;
                    }
                }
                return currencyChange;
            }
        %>

        <%
            String currencyType = request.getParameter("currencyType");
            String amountRaw = request.getParameter("amount");
            int amount = 0;
            double total = 0;
            
            try {
                if (amountRaw != null) {
                    amount = Integer.parseInt(amountRaw);
                    total = calculateRate(currencyType, amount);
                }
            } catch (Exception e) {
                amount = 0;
            }

            // Determine currency name for display
            String currencyName = "N/A";
            if ("1".equals(currencyType))
                currencyName = "USD";
            else if ("2".equals(currencyType))
                currencyName = "EURO";
            else if ("3".equals(currencyType))
                currencyName = "JPY";
            else if ("4".equals(currencyType))
                currencyName = "SGD";
        %>

        <div class="header-title">JSP Application Result</div>
        
        <div class="card-container">
            <h2>Conversion Result</h2>
            
            <div class="result-group">
                <div class="result-label">Amount in Ringgit Malaysia (RM):</div>
                <div class="result-value">RM <%= amount %></div>
            </div>

            <div class="result-group">
                <div class="result-label">Converted to (<%= currencyName %>):</div>
                <div class="result-value"><%= String.format("%.2f", total) %></div>
            </div>

            <button onclick="window.history.back()">Back to Converter</button>
        </div>

    </body>
</html>