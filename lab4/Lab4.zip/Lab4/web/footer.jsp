<%-- 
    Document   : footer
    Created on : 21 Apr 2026, 4:28:20 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
    </div> <footer style="text-align: center; padding: 15px; margin-top: 20px; color: #666; font-size: 0.9em;">
        &copy; 2026 Faculty of Computer Science and Mathematics, UMT
    </footer>
</body>
</html>