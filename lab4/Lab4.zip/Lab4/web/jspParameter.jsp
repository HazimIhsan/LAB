<%-- 
    Document   : jspParameter
    Created on : 21 Apr 2026, 3:55:24 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Using JSP Standard Action</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <div class="header-title">Using jsp:include and jsp:param to display information on JSP Page</div>

    <%
        // JSP Scriptlet defining the subject information
        String sCode = "CSE3023";
        String sSubject = "Web-based Application Development";
        String sCredit = "3(2+1)";
    %>

    <div class="card-container">
        <h2>Calling SubjectInfo.jsp Page</h2>
        
        <jsp:include page="subjectInfo.jsp" flush="true">
            <jsp:param name="code" value="<%= sCode %>" />
            <jsp:param name="subject" value="<%= sSubject %>" />
            <jsp:param name="credit" value="<%= sCredit %>" />
        </jsp:include>
    </div>

</body>
</html>
