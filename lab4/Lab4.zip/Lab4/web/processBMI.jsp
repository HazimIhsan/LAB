<%-- 
    Document   : processBMI
    Created on : 21 Apr 2026, 4:34:12 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // 5. Retrieve values
    String weightStr = request.getParameter("weight");
    String heightStr = request.getParameter("height");

    double weight = 0;
    double height = 0;
    double bmi = 0;
    String category = "Error";
    String formattedBmi = "0.00";

    // 10. Ensure proper validation using try-catch
    try {
        weight = Double.parseDouble(weightStr);
        height = Double.parseDouble(heightStr);

        // Height must not be zero
        if (height > 0) {
            // 5. Calculate BMI
            bmi = weight / (height * height);
            
            // Format to 2 decimal places here so it's easy to pass
            formattedBmi = String.format("%.2f", bmi);

            // Determine Category
            if (bmi < 18.5) {
                category = "Underweight";
            } else if (bmi >= 18.5 && bmi <= 25) {
                category = "Normal";
            } else if (bmi > 25) {
                category = "Overweight";
            }
        }
    } catch (Exception e) {
        category = "Invalid numeric input";
    }
%>

<jsp:forward page="resultBMI.jsp">
    <jsp:param name="bmiResult" value="<%= formattedBmi %>" />
    <jsp:param name="bmiCategory" value="<%= category %>" />
</jsp:forward>