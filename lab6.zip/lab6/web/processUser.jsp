<%-- 
    Document   : SampleInsertionRecord
    Created on : 12 May 2026, 3:14:43 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java" %>
<%@page import="java.sql.*" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Lab 6 - Tsk 1 - Sample Insertion record into Mysql through JSP's page</h1>
        <%
            String user = request.getParameter("username");
            String pass = request.getParameter("password");
            String fname = request.getParameter("firstname");
            String lname = request.getParameter("lastname");

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/csa3023", "root", "admin");
                String sql = "INSERT INTO userprofile VALUES (?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, user);
                ps.setString(2, pass);
                ps.setString(3, fname);
                ps.setString(4, lname);

                int i = ps.executeUpdate();
                if (i > 0) {
                    out.print("Registration Successful! <a href='login.jsp'>Login here</a>");
                }
                con.close();
            } catch (Exception e) {
                out.print("Error: " + e.getMessage());
            }
        %>
        <br>
    </body>
</html>
