<%-- 
    Document   : doLogin
    Created on : 12 May 2026, 3:54:05 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.sql.*"%>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Hello World!</h1>
        <%
            String user = request.getParameter("username");
            String pass = request.getParameter("password");

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost/csa3023", "root", "admin");
                String sql = "SELECT * FROM userprofile WHERE username=? AND password=?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, user);
                ps.setString(2, pass);

                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    // Store data in session to pass to main.jsp
                    session.setAttribute("user", rs.getString("username"));
                    session.setAttribute("fname", rs.getString("firstname"));
                    session.setAttribute("lname", rs.getString("lastname"));
                    response.sendRedirect("main.jsp");
                } else {
                    response.sendRedirect("login.jsp?msg=Invalid username or password..!");
                }
                con.close();
            } catch (Exception e) {
                out.print(e.getMessage());
            }
        %>
    </body>
</html>
