<%-- 
    Document   : main
    Created on : 12 May 2026, 3:54:40 pm
    Author     : USER
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Main Page</title>
</head>
<body>
    <h2>Welcome to the System</h2>
    <p>Username: <%= session.getAttribute("user") %></p>
    <p>First Name: <%= session.getAttribute("fname") %></p>
    <p>Last Name: <%= session.getAttribute("lname") %></p>
    <br>
    <a href="login.jsp">Logout</a>
</body>
</html>
